---
title: "PORT 111 - Rpcbind"
draft: false
images: []
description: "Portmapper Cheatsheet"
lead: "Portmapper Cheatsheet"
menu:
  docs:
    parent: "Ports"
weight: 111
toc: true
---
```
rpcinfo -p 10.11.1.111
rpcclient -U "" 10.11.1.111
    srvinfo
    enumdomusers
    getdompwinfo
    querydominfo
    netshareenum
    netshareenumall
    querydispinfo (info about ALL)
```