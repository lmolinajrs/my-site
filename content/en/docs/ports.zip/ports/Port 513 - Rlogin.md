---
title: "PORT 513 - Rlogin"
draft: false
images: []
description: "Rlogin Cheatsheet"
lead: "Rlogin Cheatsheet"
menu:
  docs:
    parent: "Ports"
weight: 513
toc: true
---
```
apt install rsh-client
rlogin -l root 10.11.1.111
```